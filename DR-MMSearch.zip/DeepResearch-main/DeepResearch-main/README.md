# MMSearch & VERL Integration

## 📖 Core Components

### 1. Multi-modal Search (MMSearch)
MMSearch is the core module of the project, implementing the following functionalities:
- **Custom Dataset Processing:** `CustomRLHFDataset`
- **Reward Scoring:** `compute_score` calculation logic.
- **Multi-modal Preprocessing:** Support for interleaved image and text data.
- **Tool Integration:** Management of tool invocation.

### 2. VERL Reinforcement Learning Framework
VERL is a general-purpose Reinforcement Learning framework providing:
- **PPO Trainer:** Robust implementation.
- **Distributed Training:** Scalable training support.
- **Parallelism Strategies:** Data Parallelism, Model Parallelism, etc.
- **Agent Loop:** The core multi-turn interaction logic is located in `Train/verl/experimental/agent_loop`.

### 3. Supported Tools
The project integrates external tools to enhance model capabilities:
- `web_text_search`: Network text search.
- `web_image_to_image_search`: Visual similarity search.

---

## 🚀 Quick Start

### 1. Environment Setup

**Create Conda Environment**
```bash
conda create -n verl python==3.10.12
conda activate verl
Install DependenciesExecute the install.sh script located in the Train directory.Note: Flash-attention must be installed manually.Bash# Download and install Flash Attention
wget -nv [https://github.com/Dao-AILab/flash-attention/releases/download/v2.8.3/flash_attn-2.8.3+cu12torch2.7cxx11abiFALSE-cp310-cp310-linux_x86_64.whl](https://github.com/Dao-AILab/flash-attention/releases/download/v2.8.3/flash_attn-2.8.3+cu12torch2.7cxx11abiFALSE-cp310-cp310-linux_x86_64.whl)
pip install --no-cache-dir flash_attn-2.8.3+cu12torch2.7cxx11abiFALSE-cp310-cp310-linux_x86_64.whl
2. Data PreparationTraining requires specific parquet files.⚠️ Important: The training set is a mixture of internal data and FVQA. The images column format has changed and is no longer a list.Training Set: /inspire/hdd/project/public/datasets.parquetValidation Set: fvqa_test.parquet (Download: HuggingFace FVQA)Search Cache: Current image-to-image search uses a local cache. (Download: HuggingFace Cache)3. Deploy Local Search ServiceRefer to the setup instructions in Search-R1.Startup Script: /inspire/hdd/project/continuinglearningtheory/public/miror/search/re.shResources: E5 model and wiki25 database/index are located at /inspire/hdd/project/continuinglearningtheory/public/wiki25.4. Start TrainingUse the provided script to launch the training job:Bashcd Train
bash run_mmsearch_grpo.sh
Environment Variables:Ensure the following variables are set correctly in the script before running:WANDB_API_KEY: (Optional) WandB API Key.SAVE_CHECKPOINT_DIR: Directory to save model checkpoints.DATASET_TRAIN: Path to the training dataset.DATASET_VAL: Path to the validation dataset.REF_MODEL_PATH: Path to the reference model.Config Updates:Update Train/deepresearch/configs/mm_search_tool_config.yaml:Set service_url to your service address.Set train_cache_path and test_cache_path to your local cache paths.⚙️ ConfigurationConfiguration files are located in Train/deepresearch/configs/.FileDescriptionmmsearch.yamlMain configuration (Training parameters, Model config).mm_search_tool_config.yamlTool configuration (External tool definitions).Tool Configuration DetailsStandard Toolsweb_text_search: Queries relevant content based on text.web_image_to_image_search: Queries similar images based on input.Note: Chuangzhi members can use the direct URLs provided in the YAML for the remote tool sandbox.Advanced ParametersSectionParameterDescriptionSearchretrieval_service_urlPath to deployed local retrieval service.num_workersThread count for retrieval service.rate_limitMax concurrent search requests.Img2Imgfvqa_train_cache_pathFVQA train set cache path.fvqa_test_cache_pathFVQA validation set cache path.all_train_cache_pathInternal train cache (File: /inspire/hdd/project//public/datasets/all_search_results_cache).🛠️ Custom Tool IntegrationTo add a new tool to the system:Register: Add the tool entry in mm_search_tool_config.yaml.Implement: Inherit from the BaseTool class in Train/verl/tools and implement the specific logic.